package com.codelads.scavengerhunt;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.codelads.scavengerhunt.Models.Game;
import com.codelads.scavengerhunt.Models.QRiddle;
import com.tomtom.online.sdk.map.TomtomMap;

import java.util.Queue;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class maingame extends AppCompatActivity
{

    TomtomMap mmap;
    @Override protected void attachBaseContext(Context newBase)
    {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override protected void onCreate(Bundle savedInstanceState)
    {
        setTheme(R.style.maintheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maingame);
        ListView CList = this.findViewById(R.id.ClueList);
        QRiddle riddle = new QRiddle("1","why you ew?","hint nigga","answer",false);
        QRiddle riddle2 = new QRiddle("1","Where is this and that?","hint nigga","answer",true);

        Game.MainGame.Questions.add(riddle);
        Game.MainGame.Questions.add(riddle2);
        Game.MainGame.Questions.add(riddle);
        Game.MainGame.Questions.add(riddle2);
        Game.MainGame.Questions.add(riddle2);
        QueueAdapter customAdapter = new QueueAdapter(this, R.layout.queue_item, Game.MainGame.Questions);

        CList .setAdapter(customAdapter);
    }


}
